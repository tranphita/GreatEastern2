import {
  Component,
  ElementRef,
  HostBinding,
  OnInit,
  ViewChild,
} from '@angular/core';
import { ApiserviceService } from '../apiservice.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  @ViewChild('teams') teams!: ElementRef;
  @HostBinding('style.--numberto1') numberto1: Number | undefined;
  @HostBinding('style.--numberto2') numberto2: Number | undefined;
  @HostBinding('style.--numberto3') numberto3: Number | undefined;
  @HostBinding('style.--numberto4') numberto4: Number | undefined;
  @HostBinding('style.--numberto5') numberto5: Number | undefined;
  @HostBinding('style.--numberto6') numberto6: Number | undefined;

  emp: any;
  locations: any;
  Pies = new Array();
  group: any;
  activeTab: string = '1';
  banners: any;
  tonghop = new Array();

  employees: any;

  constructor(private service: ApiserviceService) {}

  ngOnInit() {
    this.service.getLocationList().subscribe((data) => {
      if (data) {
        this.locations = data;
        data.forEach((value, index) => {
          this.Pies.push({ id: 'pie' + index + 1, value: value.Chart, name: value.LocationName });
        });

        this.numberto1 = this.Pies[0].value;
        this.numberto2 = this.Pies[1].value;
        this.numberto3 = this.Pies[2].value;
        this.numberto4 = this.Pies[3].value;
        this.numberto5 = this.Pies[4].value;
        this.numberto6 = this.Pies[5].value;
      }
      this.group = this.locations;
    });

    this.service.getLocationList().subscribe((datal) => {
      datal.forEach((value) => {
        this.service.getEmployeeList().subscribe((datae) => {
          var _data = datae.filter(
            (item: { Location: any }) => item.Location == value.LocationName
          );
          this.tonghop.push({
            LocationID: value.LocationID,
            LocationName: value.LocationName,
            ListEmployee: _data,
          });
        });
      });
    });

    this.service.getBannerList().subscribe((data) => {
      if (data) {
        this.banners = data;
      }
    });
    this.service.getEmployeeList().subscribe((data) => {
      this.emp = data
        .reduce((acc: any[], curr) => {
          const idx = acc.findIndex((e) => e.alphabet === curr.EmployeeName[0]);
          if (idx === -1) {
            acc.push({ alphabet: curr.EmployeeName[0], record: [curr] });
          } else {
            acc[idx].record.push(curr);
            acc[idx].record.sort((r1: { EmployeeName: number }, r2: { EmployeeName: number }) =>
              r1.EmployeeName > r2.EmployeeName ? 1 : -1
            );
          }
          return acc;
        }, [])
        .sort((e1, e2) => (e1.alphabet > e2.alphabet ? 1 : -1));
    });
  }

  list(activeTab: string) {
    var obj = this;
    this.locations = [
      { LocationID: 0, LocationName: 'Office Name' },
      ...this.group,
    ];
    this.activeTab = activeTab;
    this.teams.nativeElement.value = 0;
    (document.querySelector('.main-page') as HTMLElement).style.overflow =
      'visible';
    setTimeout(function () {
      (document.querySelector('.main-page') as HTMLElement).style.overflow =
        'hidden';
      obj.teams.nativeElement.value = 0;
    }, 10);
  }

  onSelected(e: any): void {
    this.activeTab = e.target.value;
  }

  onKey(event: any) {
    // without type info
    var param = event.target.value;
    this.service.getEmployeeList().subscribe((data) => {
      var _data = data.filter((a) =>
        a.EmployeeName.toUpperCase().includes(param.toUpperCase())
      );

      this.emp = _data
        .reduce((acc: any[], curr) => {
          const idx = acc.findIndex((e) => e.alphabet === curr.EmployeeName[0]);
          if (idx === -1) {
            acc.push({ alphabet: curr.EmployeeName[0], record: [curr] });
          } else {
            acc[idx].record.push(curr);
            acc[idx].record.sort((r1: { EmployeeName: number }, r2: { EmployeeName: number }) =>
              r1.EmployeeName > r2.EmployeeName ? 1 : -1
            );
          }
          return acc;
        }, [])
        .sort((e1, e2) => (e1.alphabet > e2.alphabet ? 1 : -1));
    });
  }

  clickPiechart() {
    var x = document.querySelector('.chartpie') as HTMLElement;
    var y = document.querySelector('.chartpie-active') as HTMLElement;
    var z = document.querySelector('.text_title') as HTMLElement;

    if (y == null) {
      x.classList.add('chartpie-active');
      x.style.transform = 'translateY(0%)';
      var nodeList = document.querySelectorAll('.animate');
      for (let i = 0; i < nodeList.length; i++) {
        nodeList[i].classList.add('animate-active');
      }

      this.Pies.forEach((value, index) => {
        var pie = document.querySelector('.pie' + (index + 1)) as HTMLElement;
        pie.classList.add('pie' + (index + 1) + '-active');
      });

      z.classList.add('text_title-active');
    } else {
      x.classList.remove('chartpie-active');
      y.style.transform = 'translateY(82%)';

      var nodeList = document.querySelectorAll('.animate');
      for (let i = 0; i < nodeList.length; i++) {
        nodeList[i].classList.remove('animate-active');
      }

      this.Pies.forEach((value, index) => {
        var pie = document.querySelector('.pie' + (index + 1)) as HTMLElement;
        pie.classList.remove('pie' + (index + 1) + '-active');
      });

      z.classList.remove('text_title-active');
    }
  }

  clickid() {
    var obj = this;
    (document.querySelector('.main-page') as HTMLElement).style.overflow =
      'visible';
    setTimeout(function () {
      (document.querySelector('.main-page') as HTMLElement).style.overflow =
        'hidden';
      obj.teams.nativeElement.value = 0;
    }, 5);
  }
}
