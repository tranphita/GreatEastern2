import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiserviceService } from '../apiservice.service';

declare function callMe(): any;

@Component({
  selector: 'app-employee-detail',
  templateUrl: './employee-detail.component.html',
  styleUrls: ['./employee-detail.component.css'],
})
export class EmployeeDetailComponent implements OnInit {
  detail = 'anonymous.PNG';

  constructor(
    private route: ActivatedRoute,
    private service: ApiserviceService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe((params) => {
      this.service
        .getEmployeeByID(params['EmployeeID'])
        .subscribe((data: any) => {
          this.detail = data.ImageDetail;
        });
    });

    callMe();
  }

  back(){
    this.router.navigate([''])
  }
}
